package it.corso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProgettoFinale1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
