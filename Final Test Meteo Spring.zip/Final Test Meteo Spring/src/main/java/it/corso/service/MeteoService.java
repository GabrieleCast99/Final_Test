package it.corso.service;

import it.corso.model.Meteo;

public interface MeteoService {

	Meteo saveMeteo(Meteo meteo);

}
