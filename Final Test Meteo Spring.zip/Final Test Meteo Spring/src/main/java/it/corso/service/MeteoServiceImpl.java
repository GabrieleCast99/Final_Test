package it.corso.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.MeteoDao;
import it.corso.model.Meteo;

@Service
public class MeteoServiceImpl implements MeteoService {
	
	@Autowired
	private MeteoDao meteoDao;
	

	@Override
	public Meteo saveMeteo(Meteo meteo) {
		return meteoDao.save(meteo);
	}

}
