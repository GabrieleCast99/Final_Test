package it.corso.dao;

import org.springframework.data.repository.CrudRepository;

import it.corso.model.Meteo;


public interface MeteoDao extends CrudRepository<Meteo, Integer> {

}
