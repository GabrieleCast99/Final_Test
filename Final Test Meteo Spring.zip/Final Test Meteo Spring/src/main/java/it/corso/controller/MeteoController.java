package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import it.corso.model.Meteo;
import it.corso.service.MeteoService;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/meteo")
public class MeteoController {

	@Autowired
	private MeteoService meteoService;
	

	@POST
	@Path("/save")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response saveMeteo(@Valid @RequestBody Meteo meteo) {
		Meteo savedMeteo = meteoService.saveMeteo(meteo);
		return Response.status(Response.Status.CREATED).entity(savedMeteo).build();
	}

}
