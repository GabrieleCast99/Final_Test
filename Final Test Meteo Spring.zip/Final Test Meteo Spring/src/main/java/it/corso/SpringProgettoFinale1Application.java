package it.corso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProgettoFinale1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringProgettoFinale1Application.class, args);
	}

}
