import React, { useState, useEffect } from 'react';
import axios from 'axios';
import moment from 'moment';
import 'bootstrap/dist/css/bootstrap.min.css';
import { WiDaySunny, WiRain, WiCloudy  } from 'weather-icons-react';

export function WeatherForecast({ coordinates, city }) {
    const [weatherData, setWeatherData] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const currentDate = new Date().toISOString();

                const response = await axios.get('https://api.open-meteo.com/v1/forecast', {
                    params: {
                        latitude: coordinates.latitude,
                        longitude: coordinates.longitude,
                        time: currentDate,
                        timezone: "Europe/Berlin",
                        current: 'temperature_2m,wind_speed_10m,relative_humidity_2m,precipitation_probability',
                        hourly: 'temperature_2m,wind_speed_10m'
                    }
                });
                setWeatherData(response.data);
            } catch (error) {
                console.error('Si è verificato un errore durante il recupero dei dati meteo:', error);
            }
        };

        fetchData();
    }, [coordinates]);

    const formatDateTime = (isoString) => {
        return moment(isoString).format('DD/MM/YYYY HH:mm');
    };

    const saveWeatherData = async () => {
        try {
            const response = await axios.post('http://127.0.0.1:8080/api/meteo/save', {
                latitude: coordinates.latitude,
                longitude: coordinates.longitude,
                temperature: weatherData.current.temperature_2m,
                windSpeed: parseFloat(weatherData.current.wind_speed_10m),
                humidity: weatherData.current.relative_humidity_2m,
                precipitationProbability: parseFloat(weatherData.current.precipitation_probability),
                datetime: weatherData.current.time,
                city: city
            });
            console.log('Informazioni meteo salvate nel database:', response.data);
        } catch (error) {
            console.error('Si è verificato un errore durante il salvataggio delle informazioni meteo:', error);
        }
    };

    const weatherIcon = (precipitationProbability) => {
        if (precipitationProbability > 60) {
            return <WiRain size={48} color='#2196f3' />;
        } else if (precipitationProbability > 30) {
            return <WiCloudy size={48} color='#2196f3' />;
        } else {
            return <WiDaySunny size={48} color='#fdd835' />;
        }
    };

    return (
        <div className='container mt-3'>
            {weatherData && (
                <div className='row justify-content-center'>
                    <div className='col-md-6'>
                        <div className='card text-center'>
                            <div className='card-body'>
                                <h5 className='card-title'>{city}</h5>
                                <h6 className='card-subtitle mb-2 text-muted'>{formatDateTime(weatherData.current.time)}</h6>
                                <p className='card-text'>Probabilitá di pioggia: {weatherData.current.precipitation_probability} % </p>
                                {weatherIcon(weatherData.current.precipitation_probability)}
                                <p className='card-text'>{weatherData.current.temperature_2m} °C</p>
                                <p className='card-text'>
                                    <small className='text-muted'>Vento: {weatherData.current.wind_speed_10m} m/s</small>
                                </p>
                                <p className='card-text'>
                                    <small className='text-muted'>Umidità: {weatherData.current.relative_humidity_2m}%</small>
                                </p>
                                <button className='btn btn-outline-primary' onClick={saveWeatherData}>Salva Dati Meteo</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
    
}