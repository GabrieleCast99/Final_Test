import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Assicurati di avere axios installato nel tuo progetto

export function WeatherForecast({ coordinates }) {
    const [weatherData, setWeatherData] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('https://api.open-meteo.com/v1/forecast', {
                    params: {
                        latitude: coordinates.latitude,
                        longitude: coordinates.longitude,
                        current: 'temperature_2m,wind_speed_10m',
                        hourly: 'temperature_2m,relative_humidity_2m,wind_speed_10m'
                    }
                });
                setWeatherData(response.data);
            } catch (error) {
                console.error('Si è verificato un errore durante il recupero dei dati meteo:', error);
            }
        };

        fetchData();
    }, [coordinates]); // Assicurati di eseguire la fetch quando le coordinate cambiano

    return (
        <div>
            {weatherData && (
                <div>
                    <h2>Weather Forecast</h2>
                    <p>Current Temperature: {weatherData.current.temperature_2m} °C</p>
                    <p>Wind Speed: {weatherData.current.wind_speed_10m} m/s</p>
                </div>
            )}
        </div>
    );
}
