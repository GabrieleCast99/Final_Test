//createBrowserRouter ci aiutera a creare il nostro oggetto di router
//RouterProvider fornitore di router
/*import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Home } from "./pages/Home/Home";
import { NotFound } from "./pages/NotFound/NotFound";

const router = createBrowserRouter([
    {
        path: "/",
        element: <Home/>
    },
    {
        path: "*",
        element: <NotFound/>
    }
]);

export function App() {
    return (
        <>
        <RouterProvider router={router}/>
        </>
    );
}*/