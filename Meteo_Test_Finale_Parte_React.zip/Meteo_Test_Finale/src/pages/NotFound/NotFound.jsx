export function NotFound() {
    return (
        <h1>Pagina non trovata</h1>
    )
}