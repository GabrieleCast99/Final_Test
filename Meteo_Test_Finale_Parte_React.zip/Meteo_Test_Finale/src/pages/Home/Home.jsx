import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../../contexts/AuthContext/AutchContext';
import { Footer } from "./Footer";
import { WeatherForecast } from '../../components/meteo/Meteo';

export function Home() {
    const { isLogged } = useContext(AuthContext);

    // Coordinate geografiche di Palermo
    const palermoCoordinates = {
        latitude: 38.1157,
        longitude: 13.3615
    };


    const MilanoCoordinates = {
        latitude: 45.4643,
        longitude: 9.1895
    };

    const RomaCoordinates = {
        latitude: 41.8919,
        longitude: 12.5113
    };

    const VeneziaCoordinates = {
        latitude: 44.4233,
        longitude: 11.1737
    };

    return (
        <div className="container text-center py-5">
    <h1 className="display-4 text-primary mb-3">Benvenuto nel Mondo del Meteo!</h1>
    <p className="lead">Scopri le previsioni meteo precise e personalizzate per la tua città.</p>
    
    {!isLogged && (
        <div className="mb-4">
            <div className="my-4">
                <Link to="/registration" className="btn btn-lg btn-primary mr-3 mb-3">Registrati Ora</Link>
                <Link to="/login" className="btn btn-lg btn-outline-primary mb-3">Accedi</Link>
                <p className="text-muted mt-3">Registrati o accedi per visualizzare il meteo aggiornato.</p>
            </div>
        </div>
    )}

        
    
    

{isLogged && (
    <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        <div style={{ flex: '50%' }}>
            <WeatherForecast coordinates={palermoCoordinates} city="Palermo" />
            <WeatherForecast coordinates={RomaCoordinates} city="Roma" />
            <WeatherForecast coordinates={VeneziaCoordinates} city="Venezia" />
        </div>
        <div style={{ flex: '50%' }}>
            <WeatherForecast coordinates={MilanoCoordinates} city="Milano" />
            <WeatherForecast coordinates={RomaCoordinates} city="Roma" />
            <WeatherForecast coordinates={VeneziaCoordinates} city="Venezia" />
        </div>
    </div>
)}

            
            
            <Footer />
        </div>
    );
}
