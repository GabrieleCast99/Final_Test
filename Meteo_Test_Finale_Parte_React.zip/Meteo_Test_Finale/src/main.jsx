import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Home } from "./pages/Home/Home";

import { NotFound } from "./pages/NotFound/NotFound";
import { Layout } from './components/Layout/Layout';
import { Login } from './pages/Login2/Login';
import "bootstrap/dist/css/bootstrap.css"
import "bootstrap/dist/js/bootstrap.js"
import { AuthContextProvider } from './contexts/AuthContext/AuthContextProvider';
import { RegistrationForm } from './components/ComponentiRest/Registration/RegistrationForm'; 

const router = createBrowserRouter([
  {
    element: (
      <AuthContextProvider>
        <Layout />
      </AuthContextProvider>
    ),
    children: [
      {
        path: '/',
        element: <Home />
      },
      {
        path: '/login',
        element: <Login />
      },
      {
        path: '/registration',
        element: <RegistrationForm />
      }
    ]
  },
  {
    path: '*',
    element: <NotFound />
  }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <RouterProvider router={router}/>
);